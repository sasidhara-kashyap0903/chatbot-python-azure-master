# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.

from .bidaf_model_runtime import BidafModelRuntime

__all__ = ["BidafModelRuntime"]
