# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.

from .bert_model_runtime import BertModelRuntime

__all__ = ["BertModelRuntime"]
