# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.

from .rich_cards_bot import RichCardsBot

__all__ = ["RichCardsBot"]
