# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.

from .console_adapter import ConsoleAdapter

__all__ = ["ConsoleAdapter"]
