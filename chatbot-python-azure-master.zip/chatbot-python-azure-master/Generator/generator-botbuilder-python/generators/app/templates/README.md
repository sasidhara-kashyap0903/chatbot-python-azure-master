# <%= botName %> Bot

This bot has been created using [Microsoft Bot Framework](https://dev.botframework.com), 

This bot is designed to do the following:

<%= description %>

## About the generator

The goal of the BotBuilder Yeoman generator is to both scaffold out a bot according to general best practices, and to provide some templates you can use when implementing commonly requested features and dialogs in your bot.

One thing to note is it's not possible to completely generate a bot or dialog, as the questions you need to ask of your user will vary wildly depending on your scenario. As such, we hope we've given you a good starting point for building your bots with Bot Framework.

## Getting Started

### Dependencies

### Structure

### Configuring the bot

- Echo dialog is designed for simple Hello, World demos and to get you started.

### Running the bot

## Additional Resources

- [Microsoft Virtual Academy Bots Course](http://aka.ms/botcourse)
- [Bot Framework Documentation](https://docs.botframework.com)
- [LUIS](https://luis.ai)
- [QnA Maker](https://qnamaker.ai)